package dev.karn.karnmining;

import dev.karn.karnmining.automation.AutomationController;
import dev.karn.karnmining.config.KarnMiningConfig;
import dev.karn.karnmining.gui.KarnMiningConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * Client entrypoint. Registers the two KarnMining keybinds with the vanilla
 * Controls screen and drives the automation controller once per tick.
 *
 * <p>Default bindings:
 * <ul>
 *   <li>Sneak + G — open the configuration menu (G is rebindable).</li>
 *   <li>Sneak + L — toggle KarnMining on/off (L is rebindable; the sneak
 *       requirement can be switched off in the configuration menu).</li>
 * </ul>
 */
public final class KarnMiningClient implements ClientModInitializer {
    public static final String MOD_ID = "karnmining";

    private static KarnMiningConfig config;
    private static AutomationController automation;
    private static class_304 activationKey;
    private static class_304 configMenuKey;

    @Override
    public void onInitializeClient() {
        config = KarnMiningConfig.load();
        automation = new AutomationController(config);

        class_304.class_11900 category = class_304.class_11900.method_74698(class_2960.method_60655(MOD_ID, "main"));

        activationKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.karnmining.activation",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_L,
            category
        ));

        configMenuKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.karnmining.config",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_G,
            category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Configuration menu: Crouch + G (the G key is rebindable).
            while (configMenuKey.method_1436()) {
                if (client.field_1724 != null && client.field_1690.field_1832.method_1434()) {
                    client.method_1507(new KarnMiningConfigScreen(null));
                }
            }

            // Activation: Sneak + L, or L alone when sneak is not required.
            while (activationKey.method_1436()) {
                if (client.field_1724 != null) {
                    toggleWithMessage(client, true);
                    break;
                }
            }

            automation.tick(client);
        });
    }

    /**
     * Toggles KarnMining and prints the "KM is Enabled"/"KM is Disabled"
     * chat message.
     *
     * @param checkSneak whether the sneak requirement should be enforced
     *                   (true when invoked from the keybind, false from the
     *                   configuration menu)
     */
    public static void toggleWithMessage(class_310 client, boolean checkSneak) {
        if (checkSneak && config.requiresSneak() && !client.field_1690.field_1832.method_1434()) {
            return;
        }
        if (!automation.toggle(client)) {
            return;
        }
        boolean enabled = automation.isEnabled();
        class_2561 message = class_2561.method_43470(enabled ? "KM is Enabled" : "KM is Disabled")
            .method_27692(enabled ? class_124.field_1060 : class_124.field_1061);
        client.field_1724.method_7353(message, false);
    }

    public static KarnMiningConfig config() {
        if (config == null) {
            config = KarnMiningConfig.load();
        }
        return config;
    }

    public static AutomationController automation() {
        if (automation == null) {
            automation = new AutomationController(config());
        }
        return automation;
    }

    public static class_304 activationKey() {
        return activationKey;
    }

    public static class_304 configMenuKey() {
        return configMenuKey;
    }
}
