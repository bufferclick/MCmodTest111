package dev.karn.karnmining.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Optional;

/**
 * Small, persistent client configuration stored as JSON in the Fabric config
 * directory ({@code config/karnmining.json}).
 */
public final class KarnMiningConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("karnmining.json");

    /** Registry id of the block to mine, e.g. {@code minecraft:diamond_ore}. */
    private String selectedBlock;

    /** Whether activation requires Sneak + keybind (true) or keybind only (false). */
    private boolean requireSneak = true;

    /** Maximum horizontal scan distance (blocks) when looking for the target block. */
    private int searchRadius = 48;

    public static KarnMiningConfig load() {
        if (!Files.isRegularFile(PATH)) {
            return new KarnMiningConfig();
        }

        try (Reader reader = Files.newBufferedReader(PATH)) {
            KarnMiningConfig config = GSON.fromJson(reader, KarnMiningConfig.class);
            if (config == null) {
                return new KarnMiningConfig();
            }
            config.searchRadius = clampRadius(config.searchRadius);
            return config;
        } catch (IOException | JsonParseException exception) {
            System.err.println("[KarnMining] Could not read config: " + exception.getMessage());
            return new KarnMiningConfig();
        }
    }

    public void save() {
        searchRadius = clampRadius(searchRadius);
        Path temporary = PATH.resolveSibling(PATH.getFileName() + ".tmp");
        try {
            Files.createDirectories(PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(temporary)) {
                GSON.toJson(this, writer);
            }
            try {
                Files.move(temporary, PATH, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ignored) {
                Files.move(temporary, PATH, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            System.err.println("[KarnMining] Could not save config: " + exception.getMessage());
        }
    }

    public Optional<class_2248> getSelectedBlock() {
        if (selectedBlock == null || selectedBlock.isBlank()) {
            return Optional.empty();
        }
        class_2960 id = class_2960.method_12829(selectedBlock);
        if (id == null || !class_7923.field_41175.method_10250(id)) {
            return Optional.empty();
        }
        return class_7923.field_41175.method_17966(id);
    }

    public void setSelectedBlock(class_2960 id) {
        selectedBlock = id.toString();
        save();
    }

    public boolean requiresSneak() {
        return requireSneak;
    }

    public void setRequiresSneak(boolean requireSneak) {
        this.requireSneak = requireSneak;
        save();
    }

    public int getSearchRadius() {
        return searchRadius;
    }

    public void setSearchRadius(int searchRadius) {
        this.searchRadius = clampRadius(searchRadius);
        save();
    }

    private static int clampRadius(int radius) {
        return Math.max(24, Math.min(64, radius));
    }
}
