package dev.karn.karnmining.automation;

import dev.karn.karnmining.config.KarnMiningConfig;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;

/**
 * Coordinates scanning, pathfinding, movement, and vanilla block breaking.
 *
 * <p>The loop is: find the nearest block of the selected type, plan a route
 * (no-mining first, mining only when necessary), walk there, mine it, then
 * immediately search for the next one. Everything is budgeted per tick so the
 * mod stays lightweight, and it only ever uses the tool the player is holding.
 */
public final class AutomationController {
    private static final int SCAN_BUDGET_PER_TICK = 12_000;
    private static final int PATH_BUDGET_PER_TICK = 900;
    private static final int REPLAN_INTERVAL = 80;   // ticks between route rechecks while walking
    private static final int MAX_BREAK_TICKS = 1_200;

    private final KarnMiningConfig config;
    private final Set<Long> ignoredTargets = new HashSet<>();

    private boolean enabled;
    private boolean controllingMovement;
    private class_638 activeWorld;
    private class_2248 selectedBlock;
    private BlockScanner scanner;
    private PathfinderJob pathfinder;
    private class_2338 target;
    private List<class_2338> path;
    private boolean pathUsesMining;
    private int pathIndex;
    private class_2338 breakingPosition;
    private int breakingTicks;
    private int waitTicks;
    private int ticks;
    private int stuckTicks;
    private double bestStepDistance = Double.MAX_VALUE;
    private int replanTimer;
    private String status = "Disabled";

    public AutomationController(KarnMiningConfig config) {
        this.config = config;
    }

    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Flips the enabled state. Returns false (and notifies the player) when
     * trying to enable without a selected block.
     */
    public boolean toggle(class_310 client) {
        if (!enabled && config.getSelectedBlock().isEmpty()) {
            if (client.field_1724 != null) {
                client.field_1724.method_7353(class_2561.method_43470("Choose a block in the KarnMining menu first."), false);
            }
            return false;
        }

        enabled = !enabled;
        if (enabled) {
            resetWork(client, "Starting...");
        } else {
            stop(client, "Disabled");
        }
        return true;
    }

    public void onConfigurationChanged(class_310 client) {
        if (enabled) {
            resetWork(client, "Configuration changed; restarting...");
        }
    }

    public void tick(class_310 client) {
        ticks++;
        if (!enabled) {
            return;
        }

        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) {
            enabled = false;
            stop(client, "Disabled");
            return;
        }

        if (client.field_1724.method_7325() || !client.field_1724.method_5805()) {
            releaseMovement(client);
            status = "Paused (spectator or dead)";
            return;
        }

        if (client.field_1755 != null) {
            releaseMovement(client);
            status = "Paused while a menu is open";
            return;
        }

        Optional<class_2248> configured = config.getSelectedBlock();
        if (configured.isEmpty()) {
            enabled = false;
            stop(client, "No block selected");
            return;
        }
        if (client.field_1687 != activeWorld || configured.get() != selectedBlock) {
            resetWork(client, "Starting...");
        }

        if (waitTicks > 0) {
            releaseMovement(client);
            waitTicks--;
            if (waitTicks == 0) {
                beginScan(client);
            }
            return;
        }

        if (scanner != null) {
            tickScanner(client);
            return;
        }
        if (pathfinder != null) {
            tickPathfinder(client);
            return;
        }
        if (target == null) {
            beginScan(client);
            return;
        }

        if (!client.field_1687.method_8320(target).method_27852(selectedBlock)) {
            finishTarget(client);
            return;
        }

        if (path == null || pathIndex >= path.size()) {
            tickTargetMining(client);
        } else {
            tickMovement(client);
        }
    }

    public String getStatus() {
        return status;
    }

    private void tickScanner(class_310 client) {
        releaseMovement(client);
        scanner.step(client.field_1687, SCAN_BUDGET_PER_TICK);
        status = "Searching loaded blocks... " + scanner.getProgressPercent() + "%";
        if (!scanner.isDone()) {
            return;
        }

        target = scanner.getResult();
        scanner = null;
        if (target == null) {
            if (!ignoredTargets.isEmpty()) {
                ignoredTargets.clear();
                status = "No reachable match; retrying all targets...";
                waitTicks = 80;
            } else {
                status = "No match within " + config.getSearchRadius() + " blocks; retrying...";
                waitTicks = 40;
            }
            return;
        }

        status = "Planning a walking route...";
        pathfinder = new PathfinderJob(client.field_1687, client.field_1724, client.field_1724.method_24515(), target);
    }

    private void tickPathfinder(class_310 client) {
        releaseMovement(client);
        pathfinder.step(PATH_BUDGET_PER_TICK);
        status = pathfinder.isMiningPhase()
            ? "Planning the quickest mining route..."
            : "Planning a no-mining route...";

        if (!pathfinder.isDone()) {
            return;
        }
        if (pathfinder.hasFailed() || pathfinder.getResult() == null) {
            pathfinder = null;
            skipTarget(client, "No safe route to that match; trying another...");
            return;
        }

        PathfinderJob.PathResult result = pathfinder.getResult();
        pathfinder = null;
        path = result.positions();
        pathUsesMining = result.usesMining();
        pathIndex = path.size() > 1 ? 1 : path.size();
        stuckTicks = 0;
        bestStepDistance = Double.MAX_VALUE;
        replanTimer = REPLAN_INTERVAL;
        status = pathUsesMining ? "Following mining route..." : "Moving to target...";
    }

    private void tickMovement(class_310 client) {
        class_746 player = client.field_1724;
        class_2338 next = path.get(pathIndex);
        double dx = next.method_10263() + 0.5 - player.method_23317();
        double dy = next.method_10264() - player.method_23318();
        double dz = next.method_10260() + 0.5 - player.method_23321();
        double horizontalSquared = dx * dx + dz * dz;
        double distance = horizontalSquared + dy * dy;

        if (horizontalSquared < 0.38 && Math.abs(dy) < 0.75) {
            pathIndex++;
            stuckTicks = 0;
            bestStepDistance = Double.MAX_VALUE;
            releaseMovement(client);
            if (pathIndex >= path.size()) {
                status = "Mining target...";
            }
            return;
        }

        replanTimer--;
        if (replanTimer <= 0) {
            replanTimer = REPLAN_INTERVAL;
            replan(client);
            if (!enabled || path == null) {
                return;
            }
        }

        class_2338 obstruction = firstObstruction(client, next);
        if (obstruction != null) {
            releaseMovement(client);
            status = "Clearing route block...";
            MiningResult mining = mineBlock(client, obstruction, false);
            if (mining == MiningResult.COMPLETE) {
                stuckTicks = 0;
                bestStepDistance = Double.MAX_VALUE;
            } else if (mining == MiningResult.OUT_OF_REACH) {
                watchForStall(client, distance);
            } else if (mining == MiningResult.UNBREAKABLE) {
                skipTarget(client, "Route became blocked; trying another target...");
            }
            return;
        }

        clearBreaking(client);
        lookAt(client, next.method_10263() + 0.5, player.method_23320(), next.method_10260() + 0.5);
        client.field_1690.field_1894.method_23481(true);
        client.field_1690.field_1867.method_23481(true);
        client.field_1690.field_1903.method_23481(dy > 0.35 || player.field_5976);
        player.method_5728(true);
        controllingMovement = true;
        status = pathUsesMining ? "Following mining route..." : "Moving to target...";
        watchForStall(client, distance);
    }

    /**
     * Re-checks the route against the current world state. Adopts a new path
     * if a better one exists, or abandons the target when it is unreachable.
     */
    private void replan(class_310 client) {
        if (target == null || !client.field_1687.method_8320(target).method_27852(selectedBlock)) {
            finishTarget(client);
            return;
        }
        PathfinderJob quick = new PathfinderJob(client.field_1687, client.field_1724, client.field_1724.method_24515(), target);
        quick.step(PATH_BUDGET_PER_TICK * 6);
        if (!quick.isDone()) {
            return; // keep the current path; retry later
        }
        if (quick.hasFailed() || quick.getResult() == null) {
            skipTarget(client, "Route became blocked; trying another target...");
            return;
        }
        PathfinderJob.PathResult result = quick.getResult();
        path = result.positions();
        pathUsesMining = result.usesMining();
        pathIndex = Math.min(path.size() - 1, 1);
        stuckTicks = 0;
        bestStepDistance = Double.MAX_VALUE;
    }

    private void tickTargetMining(class_310 client) {
        releaseMovement(client);
        status = "Mining " + selectedBlock.method_9518().getString() + "...";
        MiningResult result = mineBlock(client, target, true);
        if (result == MiningResult.COMPLETE) {
            finishTarget(client);
        } else if (result == MiningResult.UNBREAKABLE) {
            skipTarget(client, "That match cannot be mined; trying another...");
        } else if (result == MiningResult.OUT_OF_REACH) {
            path = null;
            pathfinder = new PathfinderJob(client.field_1687, client.field_1724, client.field_1724.method_24515(), target);
            status = "Target out of reach; replanning...";
        }
    }

    /**
     * Breaks {@code position} using the vanilla interaction manager. Returns
     * COMPLETE when the block is gone, UNBREAKABLE for fluid/unbreakable
     * blocks, OUT_OF_REACH when the player is too far, or IN_PROGRESS while
     * the block is being destroyed.
     */
    private MiningResult mineBlock(class_310 client, class_2338 position, boolean targetBlock) {
        class_638 world = client.field_1687;
        class_2680 state = world.method_8320(position);
        if (targetBlock ? !state.method_27852(selectedBlock)
            : state.method_26220(world, position).method_1110() && state.method_26227().method_15769()) {
            clearBreaking(client);
            return MiningResult.COMPLETE;
        }
        if (!state.method_26227().method_15769() || state.method_26214(world, position) < 0.0F) {
            clearBreaking(client);
            return MiningResult.UNBREAKABLE;
        }

        class_243 eyes = client.field_1724.method_33571();
        double centerX = position.method_10263() + 0.5;
        double centerY = position.method_10264() + 0.5;
        double centerZ = position.method_10260() + 0.5;
        if (eyes.method_1028(centerX, centerY, centerZ) > 25.0) {
            return MiningResult.OUT_OF_REACH;
        }

        lookAt(client, centerX, centerY, centerZ);
        class_2350 face = faceToward(eyes, position);
        if (!position.equals(breakingPosition)) {
            clearBreaking(client);
            breakingPosition = position.method_10062();
            client.field_1761.method_2910(position, face);
        }
        breakingTicks++;
        if (breakingTicks > MAX_BREAK_TICKS) {
            clearBreaking(client);
            return MiningResult.UNBREAKABLE;
        }
        client.field_1761.method_2902(position, face);
        if ((ticks & 3) == 0) {
            client.field_1724.method_6104(class_1268.field_5808);
        }
        return MiningResult.IN_PROGRESS;
    }

    private class_2338 firstObstruction(class_310 client, class_2338 feet) {
        class_638 world = client.field_1687;
        class_2338 current = client.field_1724.method_24515();

        if (feet.method_10264() > current.method_10264()) {
            class_2338 overhead = current.method_10086(2);
            if (isObstruction(world, overhead)) {
                return overhead;
            }
        }

        if (feet.method_10264() < current.method_10264()) {
            for (int y = current.method_10264(); y >= feet.method_10264(); y--) {
                class_2338 column = new class_2338(feet.method_10263(), y, feet.method_10260());
                if (isObstruction(world, column)) {
                    return column;
                }
            }
        }

        if (isObstruction(world, feet)) {
            return feet;
        }
        class_2338 head = feet.method_10084();
        return isObstruction(world, head) ? head : null;
    }

    private static boolean isObstruction(class_638 world, class_2338 position) {
        class_2680 state = world.method_8320(position);
        return !state.method_26220(world, position).method_1110() || !state.method_26227().method_15769();
    }

    private void watchForStall(class_310 client, double distance) {
        if (distance + 0.02 < bestStepDistance) {
            bestStepDistance = distance;
            stuckTicks = 0;
            return;
        }
        stuckTicks++;
        if (stuckTicks > 80) {
            clearBreaking(client);
            releaseMovement(client);
            path = null;
            pathfinder = new PathfinderJob(client.field_1687, client.field_1724, client.field_1724.method_24515(), target);
            status = "Route blocked; replanning...";
            stuckTicks = 0;
            bestStepDistance = Double.MAX_VALUE;
        }
    }

    private void finishTarget(class_310 client) {
        clearBreaking(client);
        releaseMovement(client);
        target = null;
        path = null;
        pathIndex = 0;
        status = "Looking for the next block...";
        waitTicks = 5;
    }

    private void skipTarget(class_310 client, String newStatus) {
        if (target != null) {
            ignoredTargets.add(target.method_10063());
        }
        clearBreaking(client);
        releaseMovement(client);
        target = null;
        path = null;
        pathIndex = 0;
        status = newStatus;
        waitTicks = 10;
    }

    private void beginScan(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || selectedBlock == null) {
            return;
        }
        target = null;
        path = null;
        pathfinder = null;
        scanner = new BlockScanner(client.field_1724.method_24515(), selectedBlock, config.getSearchRadius(), ignoredTargets);
        status = "Searching loaded blocks... 0%";
    }

    private void resetWork(class_310 client, String newStatus) {
        clearBreaking(client);
        releaseMovement(client);
        activeWorld = client.field_1687;
        selectedBlock = config.getSelectedBlock().orElse(null);
        scanner = null;
        pathfinder = null;
        target = null;
        path = null;
        pathIndex = 0;
        waitTicks = 0;
        stuckTicks = 0;
        ignoredTargets.clear();
        bestStepDistance = Double.MAX_VALUE;
        replanTimer = REPLAN_INTERVAL;
        status = newStatus;
    }

    private void stop(class_310 client, String newStatus) {
        clearBreaking(client);
        releaseMovement(client);
        scanner = null;
        pathfinder = null;
        target = null;
        path = null;
        ignoredTargets.clear();
        status = newStatus;
    }

    private void clearBreaking(class_310 client) {
        if (breakingPosition != null && client.field_1761 != null) {
            client.field_1761.method_2925();
        }
        breakingPosition = null;
        breakingTicks = 0;
    }

    private void releaseMovement(class_310 client) {
        if (!controllingMovement) {
            return;
        }
        client.field_1690.field_1894.method_23481(false);
        client.field_1690.field_1867.method_23481(false);
        client.field_1690.field_1903.method_23481(false);
        if (client.field_1724 != null) {
            client.field_1724.method_5728(false);
        }
        controllingMovement = false;
    }

    /**
     * Turns the player toward the given point and mirrors the look change to
     * the server so block breaking works correctly in multiplayer.
     */
    private void lookAt(class_310 client, double x, double y, double z) {
        class_746 player = client.field_1724;
        if (player == null) {
            return;
        }
        double dx = x - player.method_23317();
        double dy = y - player.method_23320();
        double dz = z - player.method_23321();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        player.method_36456(yaw);
        player.method_36457(Math.max(-90.0F, Math.min(90.0F, pitch)));
        if (client.method_1562() != null) {
            client.method_1562().method_52787(new class_2828.class_2831(
                yaw, pitch, player.method_24828(), player.field_5976));
        }
    }

    /** Chooses the face of the block closest to the player's eyes. */
    private static class_2350 faceToward(class_243 eyes, class_2338 position) {
        double dx = position.method_10263() + 0.5 - eyes.field_1352;
        double dy = position.method_10264() + 0.5 - eyes.field_1351;
        double dz = position.method_10260() + 0.5 - eyes.field_1350;
        double ax = Math.abs(dx);
        double ay = Math.abs(dy);
        double az = Math.abs(dz);
        if (ax >= ay && ax >= az) {
            return dx > 0 ? class_2350.field_11034 : class_2350.field_11039;
        }
        if (ay >= az) {
            return dy > 0 ? class_2350.field_11033 : class_2350.field_11036;
        }
        return dz > 0 ? class_2350.field_11035 : class_2350.field_11043;
    }

    private enum MiningResult {
        COMPLETE,
        IN_PROGRESS,
        OUT_OF_REACH,
        UNBREAKABLE
    }
}
