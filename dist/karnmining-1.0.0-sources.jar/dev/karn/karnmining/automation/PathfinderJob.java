package dev.karn.karnmining.automation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_638;
import net.minecraft.class_746;

/**
 * Tick-budgeted A* pathfinder over a bounded 3D box around the player.
 *
 * <p>It deliberately attempts a no-mining route first; only when that fails
 * does it consider breakable blocks as route cost, preferring cheap blocks
 * (dirt, stone) over expensive ones so KarnMining avoids unnecessary
 * destruction. The search is spread across ticks through {@link #step}.
 */
final class PathfinderJob {
    private static final class_2350[] HORIZONTAL = {
        class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034
    };

    private final class_638 world;
    private final class_746 player;
    private final class_2338 start;
    private final class_2338 target;
    private final Set<Long> goals = new HashSet<>();
    private final int minX;
    private final int maxX;
    private final int minY;
    private final int maxY;
    private final int minZ;
    private final int maxZ;

    private final Map<Long, Node> nodes = new HashMap<>();
    private final PriorityQueue<QueueEntry> open = new PriorityQueue<>();

    private boolean allowMining;
    private int expanded;
    private boolean done;
    private boolean failed;
    private PathResult result;

    PathfinderJob(class_638 world, class_746 player, class_2338 start, class_2338 target) {
        this.world = world;
        this.player = player;
        this.start = start.method_10062();
        this.target = target.method_10062();

        int margin = 14;
        this.minX = Math.min(start.method_10263(), target.method_10263()) - margin;
        this.maxX = Math.max(start.method_10263(), target.method_10263()) + margin;
        this.minZ = Math.min(start.method_10260(), target.method_10260()) - margin;
        this.maxZ = Math.max(start.method_10260(), target.method_10260()) + margin;
        int worldBottom = world.method_31607();
        int worldTop = worldBottom + world.method_31605() - 1;
        this.minY = Math.max(worldBottom, Math.min(start.method_10264(), target.method_10264()) - 14);
        this.maxY = Math.min(worldTop - 1, Math.max(start.method_10264(), target.method_10264()) + 14);

        buildGoals();
        beginPhase(false);
    }

    void step(int budget) {
        if (done) {
            return;
        }

        int worked = 0;
        int phaseLimit = allowMining ? 22_000 : 30_000;
        while (worked < budget && !done) {
            if (open.isEmpty() || expanded >= phaseLimit) {
                if (!allowMining) {
                    beginPhase(true);
                    return;
                }
                done = true;
                failed = true;
                return;
            }

            QueueEntry entry = open.poll();
            Node current = nodes.get(entry.position());
            if (current == null || current.closed || Math.abs(current.g - entry.g()) > 0.0001) {
                continue;
            }

            current.closed = true;
            expanded++;
            worked++;

            if (goals.contains(current.position)) {
                result = new PathResult(reconstruct(current), allowMining);
                done = true;
                return;
            }

            expandHorizontal(current);
            consider(current, class_2338.method_10092(current.position).method_10074());
        }
    }

    boolean isDone() {
        return done;
    }

    boolean hasFailed() {
        return failed;
    }

    PathResult getResult() {
        return result;
    }

    boolean isMiningPhase() {
        return allowMining;
    }

    int getExpanded() {
        return expanded;
    }

    private void beginPhase(boolean mining) {
        allowMining = mining;
        expanded = 0;
        nodes.clear();
        open.clear();
        Node first = new Node(start.method_10063(), 0.0, heuristic(start), Long.MIN_VALUE);
        nodes.put(first.position, first);
        open.add(new QueueEntry(first.position, first.g, first.f));
    }

    private void buildGoals() {
        for (class_2350 direction : HORIZONTAL) {
            class_2338 side = target.method_10093(direction);
            for (int dy = -1; dy <= 1; dy++) {
                goals.add(side.method_10086(dy).method_10063());
            }
        }
        goals.add(target.method_10084().method_10063());
        goals.add(target.method_10087(2).method_10063());
    }

    private void expandHorizontal(Node current) {
        class_2338 position = class_2338.method_10092(current.position);
        for (class_2350 direction : HORIZONTAL) {
            class_2338 side = position.method_10093(direction);
            consider(current, side.method_10084());
            consider(current, side);
            consider(current, side.method_10074());
            consider(current, side.method_10087(2));
            consider(current, side.method_10087(3));
        }
    }

    private void consider(Node from, class_2338 to) {
        if (!insideBounds(to) || !world.method_8393(to.method_10263() >> 4, to.method_10260() >> 4)) {
            return;
        }

        class_2338 fromPos = class_2338.method_10092(from.position);
        int dy = to.method_10264() - fromPos.method_10264();
        int horizontalDistance = Math.abs(to.method_10263() - fromPos.method_10263()) + Math.abs(to.method_10260() - fromPos.method_10260());
        if (horizontalDistance > 1 || dy > 1 || dy < -3 || !canOccupy(to)) {
            return;
        }

        // A jump needs room above the current head. A drop needs a clear
        // vertical column at the destination so it cannot skip through rock.
        if (dy > 0 && !canClear(fromPos.method_10086(2))) {
            return;
        }
        if (dy < -1 && horizontalDistance > 0) {
            for (int y = to.method_10264() + 1; y <= fromPos.method_10264(); y++) {
                if (!canClear(new class_2338(to.method_10263(), y, to.method_10260()))) {
                    return;
                }
            }
        }

        double movementCost = horizontalDistance == 0 ? 8.0 : 10.0;
        if (dy > 0) {
            movementCost += 6.0;
        } else if (dy < 0) {
            movementCost += 2.0 * Math.abs(dy);
        }
        double miningCost = miningCost(to);
        if (allowMining && dy > 0) {
            miningCost += costToClear(fromPos.method_10086(2));
        }
        if (allowMining && dy < -1 && horizontalDistance > 0) {
            for (int y = to.method_10264() + 2; y <= fromPos.method_10264(); y++) {
                miningCost += costToClear(new class_2338(to.method_10263(), y, to.method_10260()));
            }
        }
        double tentative = from.g + movementCost + miningCost;
        long key = to.method_10063();
        Node known = nodes.get(key);
        if (known != null && tentative >= known.g - 0.0001) {
            return;
        }

        double f = tentative + heuristic(to);
        if (known == null) {
            known = new Node(key, tentative, f, from.position);
            nodes.put(key, known);
        } else {
            known.g = tentative;
            known.f = f;
            known.parent = from.position;
            known.closed = false;
        }
        open.add(new QueueEntry(key, tentative, f));
    }

    private boolean insideBounds(class_2338 position) {
        return position.method_10263() >= minX && position.method_10263() <= maxX
            && position.method_10264() >= minY && position.method_10264() <= maxY
            && position.method_10260() >= minZ && position.method_10260() <= maxZ;
    }

    private boolean canOccupy(class_2338 feet) {
        if (!canClear(feet) || !canClear(feet.method_10084())) {
            return false;
        }
        class_2680 support = world.method_8320(feet.method_10074());
        return support.method_26227().method_15769()
            && !support.method_26220(world, feet.method_10074()).method_1110();
    }

    private boolean canClear(class_2338 position) {
        class_2680 state = world.method_8320(position);
        if (state.method_26220(world, position).method_1110() && state.method_26227().method_15769()) {
            return true;
        }
        return allowMining && canMine(position, state);
    }

    private boolean canMine(class_2338 position, class_2680 state) {
        return !position.equals(target)
            && state.method_26227().method_15769()
            && state.method_26214(world, position) >= 0.0F;
    }

    private double miningCost(class_2338 feet) {
        if (!allowMining) {
            return 0.0;
        }
        return costToClear(feet) + costToClear(feet.method_10084());
    }

    private double costToClear(class_2338 position) {
        class_2680 state = world.method_8320(position);
        if (state.method_26220(world, position).method_1110() && state.method_26227().method_15769()) {
            return 0.0;
        }
        float delta = state.method_26165(player, world, position);
        if (delta <= 0.0F) {
            return 4_000.0;
        }
        // Mining time is represented in movement-cost units. Expensive blocks
        // are avoided when a faster tunnel is available.
        return Math.min(4_000.0, Math.ceil(1.0 / delta) * 10.0);
    }

    private double heuristic(class_2338 position) {
        int dx = Math.abs(position.method_10263() - target.method_10263());
        int dy = Math.abs(position.method_10264() - target.method_10264());
        int dz = Math.abs(position.method_10260() - target.method_10260());
        return Math.max(0, dx + dy + dz - 1) * 8.0;
    }

    private List<class_2338> reconstruct(Node end) {
        List<class_2338> reverse = new ArrayList<>();
        Node current = end;
        while (current != null) {
            reverse.add(class_2338.method_10092(current.position).method_10062());
            current = current.parent == Long.MIN_VALUE ? null : nodes.get(current.parent);
        }
        Collections.reverse(reverse);
        return reverse;
    }

    record PathResult(List<class_2338> positions, boolean usesMining) {
    }

    private record QueueEntry(long position, double g, double f) implements Comparable<QueueEntry> {
        @Override
        public int compareTo(QueueEntry other) {
            int byF = Double.compare(f, other.f);
            return byF != 0 ? byF : Double.compare(g, other.g);
        }
    }

    private static final class Node {
        private final long position;
        private double g;
        private double f;
        private long parent;
        private boolean closed;

        private Node(long position, double g, double f, long parent) {
            this.position = position;
            this.g = g;
            this.f = f;
            this.parent = parent;
        }
    }
}
