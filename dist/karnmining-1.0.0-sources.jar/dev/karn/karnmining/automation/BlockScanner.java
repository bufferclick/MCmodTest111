package dev.karn.karnmining.automation;

import java.util.Arrays;
import java.util.Set;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_638;

/**
 * Incremental nearest-block scan. Offsets are sorted by squared distance, so
 * the first matching loaded block is guaranteed to be the nearest in range.
 *
 * <p>The scan is spread over multiple client ticks (see the budget in
 * {@link AutomationController}) so a full 48-block sphere never stalls a
 * frame. The offset table is cached and reused between scans.
 */
final class BlockScanner {
    private static int cachedRadius = -1;
    private static long[] cachedOffsets = new long[0];

    private final class_2338 center;
    private final class_2248 wanted;
    private final int radius;
    private final long[] offsets;
    private final Set<Long> ignoredPositions;
    private int cursor;
    private class_2338 result;
    private boolean done;

    BlockScanner(class_2338 center, class_2248 wanted, int radius, Set<Long> ignoredPositions) {
        this.center = center.method_10062();
        this.wanted = wanted;
        this.radius = radius;
        this.offsets = offsetsFor(radius);
        this.ignoredPositions = ignoredPositions;
    }

    void step(class_638 world, int budget) {
        if (done) {
            return;
        }

        class_2338.class_2339 mutable = new class_2338.class_2339();
        int bottom = world.method_31607();
        int topExclusive = bottom + world.method_31605();
        int checked = 0;

        while (cursor < offsets.length && checked < budget) {
            long encoded = offsets[cursor++];
            int dx = (int) ((encoded >>> 16) & 0xFFL) - radius;
            int dy = (int) ((encoded >>> 8) & 0xFFL) - radius;
            int dz = (int) (encoded & 0xFFL) - radius;
            int x = center.method_10263() + dx;
            int y = center.method_10264() + dy;
            int z = center.method_10260() + dz;
            checked++;

            if (y < bottom || y >= topExclusive || !world.method_8393(x >> 4, z >> 4)) {
                continue;
            }

            mutable.method_10103(x, y, z);
            if (!ignoredPositions.contains(mutable.method_10063()) && world.method_8320(mutable).method_27852(wanted)) {
                result = mutable.method_10062();
                done = true;
                return;
            }
        }

        if (cursor >= offsets.length) {
            done = true;
        }
    }

    boolean isDone() {
        return done;
    }

    class_2338 getResult() {
        return result;
    }

    int getProgressPercent() {
        return offsets.length == 0 ? 100 : Math.min(100, cursor * 100 / offsets.length);
    }

    private static synchronized long[] offsetsFor(int radius) {
        if (cachedRadius == radius) {
            return cachedOffsets;
        }

        int diameter = radius * 2 + 1;
        int estimate = (int) Math.ceil(4.0 / 3.0 * Math.PI * radius * radius * radius) + 1;
        long[] values = new long[Math.max(estimate, diameter)];
        int size = 0;
        int radiusSquared = radius * radius;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    int distanceSquared = dx * dx + dy * dy + dz * dz;
                    if (distanceSquared > radiusSquared) {
                        continue;
                    }
                    if (size == values.length) {
                        values = Arrays.copyOf(values, values.length + Math.max(1024, values.length / 4));
                    }
                    values[size++] = ((long) distanceSquared << 24)
                        | ((long) (dx + radius) << 16)
                        | ((long) (dy + radius) << 8)
                        | (long) (dz + radius);
                }
            }
        }

        cachedOffsets = Arrays.copyOf(values, size);
        Arrays.sort(cachedOffsets);
        cachedRadius = radius;
        return cachedOffsets;
    }
}
