package dev.karn.karnmining.gui;

import dev.karn.karnmining.KarnMiningClient;
import dev.karn.karnmining.automation.AutomationController;
import dev.karn.karnmining.config.KarnMiningConfig;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_6599;
import net.minecraft.class_7923;

/**
 * Vanilla-styled configuration menu. Opened with Crouch + G (rebindable
 * through the Controls screen); every widget uses the standard Minecraft
 * button/text styling and fonts.
 */
public final class KarnMiningConfigScreen extends class_437 {
    private static final int[] RADII = {24, 32, 48, 64};

    private final class_437 parent;

    public KarnMiningConfigScreen(class_437 parent) {
        super(class_2561.method_43470("KarnMining Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        KarnMiningConfig config = KarnMiningClient.config();
        int center = field_22789 / 2;
        int buttonWidth = Math.min(280, field_22789 - 40);
        int left = center - buttonWidth / 2;
        int y = 92;

        method_37063(class_4185.method_46430(toggleLabel(), button -> {
                KarnMiningClient.toggleWithMessage(field_22787, false);
                button.method_25355(toggleLabel());
            })
            .method_46434(left, y, buttonWidth, 20)
            .method_46431());
        y += 24;

        method_37063(class_4185.method_46430(class_2561.method_43470("Choose Block..."), button ->
                field_22787.method_1507(new BlockSelectionScreen(this)))
            .method_46434(left, y, buttonWidth, 20)
            .method_46431());
        y += 24;

        method_37063(class_4185.method_46430(sneakLabel(config), button -> {
                config.setRequiresSneak(!config.requiresSneak());
                button.method_25355(sneakLabel(config));
            })
            .method_46434(left, y, buttonWidth, 20)
            .method_46431());
        y += 24;

        method_37063(class_4185.method_46430(radiusText(config), button -> {
                int next = nextRadius(config.getSearchRadius());
                config.setSearchRadius(next);
                button.method_25355(radiusText(config));
                KarnMiningClient.automation().onConfigurationChanged(field_22787);
            })
            .method_46434(left, y, buttonWidth, 20)
            .method_46431());
        y += 24;

        class_2561 keys = class_2561.method_43470("Keys: Toggle ")
            .method_10852(KarnMiningClient.activationKey().method_16007())
            .method_27693("  /  Menu ")
            .method_10852(KarnMiningClient.configMenuKey().method_16007())
            .method_27693("  (Controls...)");
        method_37063(class_4185.method_46430(keys, button ->
                field_22787.method_1507(new class_6599(this, field_22787.field_1690)))
            .method_46434(left, y, buttonWidth, 20)
            .method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("Done"), button -> method_25419())
            .method_46434(center - 100, field_22790 - 28, 200, 20)
            .method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        method_25420(context, mouseX, mouseY, deltaTicks);
        context.method_27534(field_22793, field_22785, field_22789 / 2, 16, 0xFFFFFF);

        Optional<class_2248> selected = KarnMiningClient.config().getSelectedBlock();
        if (selected.isPresent()) {
            class_2248 block = selected.get();
            context.method_27534(field_22793,
                class_2561.method_43470("Selected: ").method_10852(block.method_9518()).method_27692(class_124.field_1060),
                field_22789 / 2, 42, 0xFFFFFF);
            context.method_51427(block.method_8389().method_7854(), field_22789 / 2 - 8, 58);
            context.method_27534(field_22793,
                class_2561.method_43470(class_7923.field_41175.method_10221(block).toString()).method_27692(class_124.field_1080),
                field_22789 / 2, 78, 0xFFFFFF);
        } else {
            context.method_27534(field_22793,
                class_2561.method_43470("Selected: None — choose a block to start mining.").method_27692(class_124.field_1054),
                field_22789 / 2, 44, 0xFFFFFF);
        }

        String status = KarnMiningClient.automation().getStatus();
        context.method_27534(field_22793, class_2561.method_43470("Status: " + status),
            field_22789 / 2, 220, 0xA0A0A0);

        context.method_27534(field_22793,
            class_2561.method_43470("Warning: automation may violate server rules and can result in a ban.")
                .method_27692(class_124.field_1061),
            field_22789 / 2, field_22790 - 46, 0xFFFFFF);

        super.method_25394(context, mouseX, mouseY, deltaTicks);
    }

    @Override
    public void method_25419() {
        KarnMiningClient.config().save();
        if (parent != null) {
            field_22787.method_1507(parent);
        } else {
            field_22787.method_1507(null);
        }
    }

    private static class_2561 toggleLabel() {
        AutomationController automation = KarnMiningClient.automation();
        return class_2561.method_43470(automation.isEnabled() ? "Disable KarnMining" : "Enable KarnMining");
    }

    private static class_2561 sneakLabel(KarnMiningConfig config) {
        String key = KarnMiningClient.activationKey().method_16007().getString();
        return class_2561.method_43470(config.requiresSneak()
            ? "Activation: Sneak + " + key
            : "Activation: " + key + " (no sneak)");
    }

    private static class_2561 radiusText(KarnMiningConfig config) {
        return class_2561.method_43470("Search Radius: " + config.getSearchRadius() + " blocks");
    }

    private static int nextRadius(int current) {
        for (int i = 0; i < RADII.length; i++) {
            if (RADII[i] == current) {
                return RADII[(i + 1) % RADII.length];
            }
            if (RADII[i] > current) {
                return RADII[i];
            }
        }
        return RADII[0];
    }
}
