package dev.karn.karnmining.gui;

import dev.karn.karnmining.KarnMiningClient;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7923;

/**
 * Searchable, page-scrollable grid of every obtainable block in the registry,
 * styled like the vanilla creative inventory. The list is generated from
 * {@link class_7923#field_41175} at runtime, so it always matches the current game.
 */
public final class BlockSelectionScreen extends class_437 {
    private static final int CELL = 20;      // grid pitch
    private static final int CELL_SIZE = 18; // cell size (icon 16 + border)
    private static final class_2561 EMPTY = class_2561.method_43470("");

    private final class_437 parent;
    private final List<class_2248> allBlocks;

    private final List<BlockCell> cells = new ArrayList<>();
    private List<class_2248> filteredBlocks;
    private class_342 searchField;
    private class_4185 previousButton;
    private class_4185 pageButton;
    private class_4185 nextButton;
    private String query = "";
    private int page;
    private int columns;
    private int rows;
    private int gridLeft;
    private int gridTop;
    private int gridWidth;

    public BlockSelectionScreen(class_437 parent) {
        super(class_2561.method_43470("Choose a Block"));
        this.parent = parent;
        // Every registered block that has an item (i.e. is obtainable), sorted
        // by registry id so the list is stable across languages and sessions.
        this.allBlocks = class_7923.field_41175.method_10220()
            .filter(block -> block.method_8389() != class_1802.field_8162)
            .sorted(Comparator.comparing(block -> class_7923.field_41175.method_10221(block).toString()))
            .toList();
        this.filteredBlocks = allBlocks;
    }

    @Override
    protected void method_25426() {
        int contentWidth = Math.min(440, field_22789 - 24);
        gridLeft = (field_22789 - contentWidth) / 2;
        gridWidth = contentWidth;
        gridTop = 58;
        rows = Math.max(3, Math.min(10, (field_22790 - 120) / CELL));
        columns = Math.max(1, gridWidth / CELL);

        searchField = new class_342(field_22793, gridLeft, 28, gridWidth - 76, 20, class_2561.method_43470("Search blocks"));
        searchField.method_1880(80);
        searchField.method_1852(query);
        searchField.method_1863(text -> applySearch());
        method_37063(searchField);

        method_37063(class_4185.method_46430(class_2561.method_43470("Search"), button -> applySearch())
            .method_46434(gridLeft + gridWidth - 72, 28, 72, 20)
            .method_46431());

        int navigationY = gridTop + rows * CELL + 6;

        previousButton = class_4185.method_46430(class_2561.method_43470("<"), button -> {
                page--;
                layout();
            })
            .method_46434(field_22789 / 2 - 104, navigationY, 40, 20)
            .method_46431();
        method_37063(previousButton);

        pageButton = class_4185.method_46430(class_2561.method_43470("Page 1 / 1"), button -> { })
            .method_46434(field_22789 / 2 - 60, navigationY, 120, 20)
            .method_46431();
        pageButton.field_22763 = false;
        method_37063(pageButton);

        nextButton = class_4185.method_46430(class_2561.method_43470(">"), button -> {
                page++;
                layout();
            })
            .method_46434(field_22789 / 2 + 64, navigationY, 40, 20)
            .method_46431();
        method_37063(nextButton);

        method_37063(class_4185.method_46430(class_2561.method_43470("Back"), button -> method_25419())
            .method_46434(field_22789 / 2 - 50, field_22790 - 26, 100, 20)
            .method_46431());

        cells.clear();
        for (int index = 0; index < allBlocks.size(); index++) {
            class_2248 block = allBlocks.get(index);
            class_4185 button = class_4185.method_46430(EMPTY, pressed -> select(block))
                .method_46434(0, -10_000, CELL_SIZE, CELL_SIZE)
                .method_46431();
            cells.add(new BlockCell(index, block, button));
            method_37063(button);
        }

        page = 0;
        layout();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        method_25420(context, mouseX, mouseY, deltaTicks);
        context.method_27534(field_22793, field_22785, field_22789 / 2, 12, 0xFFFFFF);

        for (BlockCell cell : cells) {
            if (cell.button.field_22764) {
                int x = cell.button.method_46426();
                int y = cell.button.method_46427();
                context.method_51427(cell.stack, x + 1, y + 1);
                if (cell.selected) {
                    int w = cell.button.method_25368();
                    int h = cell.button.method_25364();
                    context.method_25294(x, y, x + w, y + 1, 0xFF55FF55);
                    context.method_25294(x, y + h - 1, x + w, y + h, 0xFF55FF55);
                    context.method_25294(x, y, x + 1, y + h, 0xFF55FF55);
                    context.method_25294(x + w - 1, y, x + w, y + h, 0xFF55FF55);
                }
            }
        }

        class_2561 info = class_2561.method_43470(filteredBlocks.size() + " / " + allBlocks.size() + " blocks");
        Optional<class_2248> selected = KarnMiningClient.config().getSelectedBlock();
        if (selected.isPresent()) {
            info = class_2561.method_43470("").method_10852(info).method_27693("  -  Selected: ")
                .method_10852(selected.get().method_9518().method_27692(class_124.field_1060));
        }
        context.method_27534(field_22793, info, field_22789 / 2, field_22790 - 40, 0xA0A0A0);

        class_2248 hovered = hoveredBlock(mouseX, mouseY);
        if (hovered != null) {
            context.method_27534(field_22793,
                class_2561.method_43470(hovered.method_9518().getString() + "  (")
                    .method_27693(class_7923.field_41175.method_10221(hovered).toString()).method_27693(")"),
                field_22789 / 2, gridTop - 12, 0xFFFFFF);
        }

        super.method_25394(context, mouseX, mouseY, deltaTicks);
    }

    private void select(class_2248 block) {
        KarnMiningClient.config().setSelectedBlock(class_7923.field_41175.method_10221(block));
        KarnMiningClient.automation().onConfigurationChanged(field_22787);
        field_22787.method_1507(parent);
    }

    private void applySearch() {
        query = searchField.method_1882().trim();
        String normalized = query.toLowerCase(Locale.ROOT);
        String underscored = normalized.replace(' ', '_');
        filteredBlocks = normalized.isEmpty() ? allBlocks : allBlocks.stream()
            .filter(block -> matches(block, normalized, underscored))
            .toList();
        page = 0;
        layout();
    }

    private static boolean matches(class_2248 block, String query, String underscored) {
        class_2960 id = class_7923.field_41175.method_10221(block);
        String idString = id.toString().toLowerCase(Locale.ROOT);
        String name = block.method_9518().getString().toLowerCase(Locale.ROOT);
        return idString.contains(query)
            || idString.contains(underscored)
            || name.contains(query)
            || name.contains(underscored.replace('_', ' '));
    }

    /** Positions every cell for the current search results and page. */
    private void layout() {
        int perPage = rows * columns;
        int pageCount = Math.max(1, (filteredBlocks.size() + perPage - 1) / perPage);
        page = Math.max(0, Math.min(page, pageCount - 1));
        int start = page * perPage;
        int end = Math.min(filteredBlocks.size(), start + perPage);
        class_2248 configured = KarnMiningClient.config().getSelectedBlock().orElse(null);

        for (BlockCell cell : cells) {
            int index = cell.index;
            boolean visible = index >= start && index < end;
            if (visible) {
                int position = index - start;
                int column = position % columns;
                int row = position / columns;
                cell.button.method_46421(gridLeft + 2 + column * CELL);
                cell.button.method_46419(gridTop + 2 + row * CELL);
            }
            cell.button.field_22764 = visible;
            cell.selected = visible && filteredBlocks.get(index) == configured;
            if (!visible) {
                cell.button.method_46419(-10_000); // keep it out of hit-testing
            }
        }

        previousButton.field_22763 = page > 0;
        nextButton.field_22763 = page + 1 < pageCount;
        pageButton.method_25355(class_2561.method_43470("Page " + (page + 1) + " / " + pageCount));
    }

    private class_2248 hoveredBlock(int mouseX, int mouseY) {
        for (BlockCell cell : cells) {
            if (cell.button.field_22764 && cell.button.method_25405(mouseX, mouseY)) {
                return cell.block;
            }
        }
        return null;
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }

    /** Data for one grid cell: the block, its item icon, and its button. */
    private static final class BlockCell {
        private final int index;
        private final class_2248 block;
        private final class_1799 stack;
        private final class_4185 button;
        private boolean selected;

        private BlockCell(int index, class_2248 block, class_4185 button) {
            this.index = index;
            this.block = block;
            this.stack = block.method_8389().method_7854();
            this.button = button;
        }
    }
}
